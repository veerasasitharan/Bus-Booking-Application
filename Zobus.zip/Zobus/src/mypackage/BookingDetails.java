package mypackage;

public class BookingDetails
{
    String passengerName=null;
    String passengerGender=null;
    String bookingStatus=null;
    String busType=null;
    char seatRow;
    int seatNo=0,bookingCustomerId=0,bookingId=0,seatId=0;
    BookingDetails(String passengerName,String passengerGender,String busType,char seatRow,int seatNo,int bookingCustomerId,int bookingId,String bookingStatus,int seatId)
    {
        this.passengerName=passengerName;
        this.passengerGender=passengerGender;
        this.busType=busType;
        this.seatRow=seatRow;
        this.seatNo=seatNo;
        this.bookingCustomerId=bookingCustomerId;
        this.bookingId=bookingId;
        this.bookingStatus=bookingStatus;
        this.seatId=seatId;
    }
}
