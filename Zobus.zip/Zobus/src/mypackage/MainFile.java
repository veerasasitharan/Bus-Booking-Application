package mypackage;

import java.util.Scanner;
public class MainFile
{
    static BookingDetails[] bookingDetailsObjects=new BookingDetails[50];
   static CustomerDetails[] customerObjects=new CustomerDetails[50];
   static BusSeat[] busSeatObjects=new BusSeat[48];
   static BusDetails[] busObjects=new BusDetails[4];
    public static void intiallization()
    {
        busObjects[0]=new BusDetails("AC-sleeper",0,700,0,0);
        busObjects[1]=new BusDetails("AC-seater",1,550,0,0);
        busObjects[2]=new BusDetails("NonAC-sleeper",2,600,0,0);
        busObjects[3]=new BusDetails("NonAC-seater",3,450,0,0);
        int i,j;
        char seatRow='A';

        for(i=0;i<12;i++)
        {
            if(i==4)
                seatRow='B';
            if(i==8)
                seatRow='C';
            j=(i+1)%4!=0?(i+1)%4:4;
            busSeatObjects[i]=new BusSeat(0,j,seatRow,"Availabel",i);
        }


        seatRow='A';
        for(i=12;i<24;i++)
        {
            if(i==16)
                seatRow='B';
            if(i==20)
                seatRow='C';
            j=(i+1)%4!=0?(i+1)%4:4;
            busSeatObjects[i]=new BusSeat(1,j,seatRow,"Availabel",i);
        }


        seatRow='A';
        for(i=24;i<36;i++)
        {
            if(i==28)
                seatRow='B';
            if(i==32)
                seatRow='C';
            j=(i+1)%4!=0?(i+1)%4:4;
            busSeatObjects[i]=new BusSeat(2,j,seatRow,"Availabel",i);
        }


        seatRow='A';
        for(i=36;i<48;i++)
        {
            if(i==40)
                seatRow='B';
            if(i==44)
                seatRow='C';
            j=(i+1)%4!=0?(i+1)%4:4;
            busSeatObjects[i]=new BusSeat(3,j,seatRow,"Availabel",i);
        }


        customerObjects[0]=new CustomerDetails(0,"aaa",111,12,"F",0);
        customerObjects[1]=new CustomerDetails(1,"bbb",222,21,"M",0);
        customerObjects[2]=new CustomerDetails(2,"ccc",333,25,"M",0);
        customerObjects[3]=new CustomerDetails(3,"ddd",444,61,"F",0);
//        for(i=0;i<48;i++)
//        {
//            System.out.println(busSeatObjects[i].busId+" "+busSeatObjects[i].seatRow+" "+busSeatObjects[i].seatNo);
//        }
    }

    static int customerNo=4,choice=0,bookingNo=0,Totalcancellationfee=0;
    public static void main(String[] args)
    {
        System.out.println("Welcome To Zobus - Bus Booking Application");
        MainFile.intiallization();
       // System.out.println(MainFile.customerObjects[0].customerName);
       int i=0;
        Scanner scan=new Scanner(System.in);
        do {
            System.out.println("1.Login as Admin");
            System.out.println("2.SignUp as User");
            System.out.println("3.Login as User");
            System.out.println("4.Exit");
            System.out.println("Enter Your Choice");
            choice=scan.nextInt();
            int adminChoice=0;
            if(choice==1)
            {
                System.out.println("I am Admin");

                do {
                    System.out.println("1.Bus Summary");
                    System.out.println("2.Back");
                    adminChoice=scan.nextInt();
                    if(adminChoice==1)
                    {
                        System.out.println("Total Amount    "+MainFile.Totalcancellationfee);
                        System.out.println("   BusType     Bookedseats     TotalFareCollected    NoOfCancellation");
                        for(int f=0;f<4;f++)
                        {
                            System.out.println((f+1)+" "+MainFile.busObjects[f].busType+"      "+MainFile.busObjects[f].bookedSeats+"       "+MainFile.busObjects[f].totalBusFare+"        "+MainFile.busObjects[f].cancellationNo);
                            //System.out.println("Seat Details Are");
                            for(int r=0;r<MainFile.bookingNo;r++)
                            {
                                if(MainFile.bookingDetailsObjects[r].busType.equals(MainFile.busObjects[f].busType)&&MainFile.bookingDetailsObjects[r].bookingStatus.equals("Conformed"))
                                {
                                    System.out.println(MainFile.bookingDetailsObjects[r].passengerName+"        "+MainFile.bookingDetailsObjects[r].passengerGender+"       "+MainFile.bookingDetailsObjects[r].seatRow+"       "+MainFile.bookingDetailsObjects[r].seatNo);
                                }
                            }
                            System.out.println();
                        }
                    } else if (adminChoice>2) {
                        System.out.println("Invalid");
                    }

                }while(adminChoice!=2);

            }
            else if(choice==2)
            {
                System.out.println("Welcome to SignUp Page");

                System.out.println("Enter Your Name");
                System.out.println("Enter Your Password");
                System.out.println("Enter Your Age");
                System.out.println("Enter Your Gender i.e Male - M, Female - F ");
                customerObjects[customerNo] =new CustomerDetails(customerNo,scan.next(),scan.nextInt(),scan.nextInt(),scan.next(),0);
                customerNo++;
            } else if (choice==3)
            {
                System.out.println("Welcome to Login Page");
                LoginClass.main(args);

            } else if(choice>4) {
                System.out.println("Invalid Input");
            }
        }while (choice!=4);
        System.out.println("Thank you Happy Journey!!!");
    }
}
