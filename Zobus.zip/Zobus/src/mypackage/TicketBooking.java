package mypackage;

import java.util.Scanner;

public class TicketBooking
{
    public static void toBookTicket()
    {
        Scanner scan=new Scanner(System.in);
        int choice=0;
        int[] busFilter=new int[4];
        String[] busFiltername=new String[4];
        String tem=null;
        int i,numberoftickets=0,j;
        int availabelSeatNo = 0;
        boolean isValiduserName=false;
        String busType=null;
        busFilter[0]=MainFile.busObjects[0].availableSeat;
        busFilter[1]=MainFile.busObjects[1].availableSeat;
        busFilter[2]=MainFile.busObjects[2].availableSeat;
        busFilter[3]=MainFile.busObjects[3].availableSeat;
        busFiltername[0]=MainFile.busObjects[0].busType;
        busFiltername[1]=MainFile.busObjects[1].busType;
        busFiltername[2]=MainFile.busObjects[2].busType;
        busFiltername[3]=MainFile.busObjects[3].busType;
        System.out.println();
        System.out.println();
        System.out.println();
       // System.out.println("Enter BusType You Want");
      //   busType = scan.next();

        System.out.println("Enter Number of Ticket You Want");
        numberoftickets = scan.nextInt();
        System.out.println("Choose BusType You Want");
        System.out.println("1.AC");
        System.out.println("2.NonAC");
        System.out.println("3.Both");
        int busChoice=scan.nextInt();
        System.out.println("1.Sleeper");
        System.out.println("2.Seater");
        System.out.println("3.Both");
        int busSeatChoice=scan.nextInt();
        if(busChoice==1&&busChoice==1)
        {
            busType="AC-sleeper";
        }
        if(busChoice==1 && busSeatChoice==2)
        {
            busType="AC-seater";
        }
        if(busChoice==2&&busSeatChoice==1)
        {
           busType="NonAC-sleeper";
        }
        if(busChoice==2&&busSeatChoice==2)
        {
            busType="NonAC-seater";
        }
        for(int t=0;t<4;t++)
        {
            for(int y=t+1;y<4;y++)
            {
                if(busFilter[t]<busFilter[y])
                {
                    busFilter[t]=busFilter[t]+busFilter[y]-(busFilter[y]=busFilter[t]);
                    tem=busFiltername[t];
                    busFiltername[t]=busFiltername[y];
                    busFiltername[y]=tem;
                } else if (busFilter[t]<=busFilter[y]&&busFiltername[y].startsWith("A")&&busFiltername[y].charAt(4)=='l') {
                    tem=busFiltername[t];
                    busFiltername[t]=busFiltername[y];
                    busFiltername[y]=tem;

                }
            }if(busFiltername[t].equals(busType) &&busChoice!=3&&busSeatChoice!=3)
            System.out.println(busFiltername[t]+"        "+busFilter[t]);
            else if(busChoice==3&&busSeatChoice==3)
            {
                System.out.println((t+1)+".      "+busFiltername[t]+"        "+busFilter[t]);

            }
            else if(busChoice==3 && busSeatChoice==1)
            {

                if(busFiltername[t].startsWith("A"))
                {

                    if(busFiltername[t].charAt(4)=='l')
                    {
                        System.out.println(t+".      "+busFiltername[t]+"        "+busFilter[t]);
                    }

                } if (busFiltername[t].startsWith("N")) {

                    if(busFiltername[t].charAt(7)=='l')
                    {
                        System.out.println(t+".      "+busFiltername[t]+"        "+busFilter[t]);
                    }

                }

            }
        else if(busChoice==3 && busSeatChoice==2)
        {

            if(busFiltername[t].startsWith("A"))
            {

                if(busFiltername[t].charAt(4)=='e')
                {
                    System.out.println(t+".      "+busFiltername[t]+"        "+busFilter[t]);
                }

            } if (busFiltername[t].startsWith("N")) {

            if(busFiltername[t].charAt(7)=='e')
            {
                System.out.println(t+".      "+busFiltername[t]+"        "+busFilter[t]);
            }
        }

        }
//next
        else if(busChoice==1 && busSeatChoice==3)
        {

            if(busFiltername[t].startsWith("A"))
            {


                    System.out.println(t+".      "+busFiltername[t]+"        "+busFilter[t]);


            }
        }
        else if(busChoice==2 && busSeatChoice==3)
        {

            if(busFiltername[t].startsWith("N"))
            {
                System.out.println(t+".      "+busFiltername[t]+"        "+busFilter[t]);

            }
        }

        }
        int finallchoice=0;

       if(busChoice==3&&busSeatChoice==3)
       {
           System.out.println("Enter Your Choice");
           finallchoice=scan.nextInt();
         for(int tt=0;tt<4;tt++)
         {
             if(finallchoice-1==tt)
             {
                 busType=busFiltername[tt];
                 break;
             }
         }
       }
        if(busChoice==3 && busSeatChoice==1)
        {
            System.out.println("Enter Your Choice");
            finallchoice=scan.nextInt();
            for(int tt=0;tt<4;tt++)
            {
                if(finallchoice==tt)
                {
                    busType=busFiltername[tt];
                    break;
                }
            }
        }
        if(busChoice==3 && busSeatChoice==2)
        {
            System.out.println("Enter Your Choice");
            finallchoice=scan.nextInt();
            for(int tt=0;tt<4;tt++)
            {
                if(finallchoice==tt)
                {
                    busType=busFiltername[tt];
                    break;
                }
            }
        }
        //next
        if(busChoice==1 && busSeatChoice==3)
        {
            System.out.println("Enter Your Choice");
            finallchoice=scan.nextInt();
            for(int tt=0;tt<4;tt++)
            {
                if(finallchoice==tt)
                {
                    busType=busFiltername[tt];
                    break;
                }
            }
        }
        if(busChoice==2 && busSeatChoice==3)
        {
            System.out.println("Enter Your Choice");
            finallchoice=scan.nextInt();
            for(int tt=0;tt<4;tt++)
            {
                if(finallchoice==tt)
                {
                    busType=busFiltername[tt];
                    break;
                }
            }
        }

        boolean isAccepted = false;
        for (i = 0; i < 4; i++) {
            if (MainFile.busObjects[i].busType.equals(busType))
            {
                if (numberoftickets <= MainFile.busObjects[i].availableSeat)
                {
                    isAccepted = true;
                }
            }
        }
        if (isAccepted)
        {


            for (i = 0; i < 4; i++) {
                if (MainFile.busObjects[i].busType.equals(busType)) {
                    int k = 4, temp = 1;
                    int start = i * 12;
                    int end = start + 12;
                    System.out.println("    A           B            C");
                    for (j = 0; j < 4; j++, start++) {


                        System.out.print(j + 1 + "   " + MainFile.busSeatObjects[start].seatStatus);
                        System.out.print(" " + "    " + MainFile.busSeatObjects[start + k].seatNo + "   " + MainFile.busSeatObjects[k + start].seatStatus);
                        System.out.print(" " + "    " + MainFile.busSeatObjects[k + k + start].seatNo + "   " + MainFile.busSeatObjects[k + k + start].seatStatus);
                        System.out.println();

                    }
                    break;
                }
            }


            String passengerName = null, passengerGender = null;
            char seatRow;
            int seatNo;
            int confirmation;

            for (int l = 0; l < MainFile.customerNo; l++) {
                if (MainFile.customerObjects[l].customerId == LoginClass.customerId) {
                    for (int r = 0; r < numberoftickets; ) {
                        System.out.println("Passenger Name");
                        System.out.println("Passenger Gender");
                        System.out.println("Passenger seatRow");
                        System.out.println("Passenger SeatNo");
                        passengerName = scan.next();
                        passengerGender = scan.next();
                        seatRow = scan.next().charAt(0);
                        seatNo = scan.nextInt();
                        availabelSeatNo = LoginClass.isAvailabel(busType, seatNo, seatRow, LoginClass.customerId,passengerGender);
                        if (availabelSeatNo != -1) {
                            System.out.println(passengerName + "   " + passengerGender + "     " + busType + "     " + seatNo + "      " + seatRow);
                            System.out.println("1.For Confirmation");
                            System.out.println("2.For Not Confirmation");
                            confirmation = scan.nextInt();
                            if (confirmation == 1) {
                                r++;
                                MainFile.bookingDetailsObjects[MainFile.bookingNo] = new BookingDetails(passengerName, passengerGender, busType, seatRow, seatNo,LoginClass.customerId,MainFile.bookingNo,"Conformed",availabelSeatNo);

                                MainFile.bookingNo++;
                                MainFile.busSeatObjects[availabelSeatNo].seatStatus = passengerGender;
                                MainFile.customerObjects[LoginClass.customerId].totalbookedtickets += 1;
                                MainFile.customerObjects[LoginClass.customerId].customertotalfare += MainFile.busObjects[LoginClass.busId].busFare;
                                MainFile.busObjects[LoginClass.busId].totalBusFare+=MainFile.busObjects[LoginClass.busId].busFare;
                                MainFile.busObjects[LoginClass.busId].bookedSeats += 1;
                                MainFile.busObjects[LoginClass.busId].availableSeat -= 1;
                                // System.out.println(MainFile.bookingDetailsObjects[MainFile.bookingNo-1].bookingId+"      "+MainFile.bookingDetailsObjects[MainFile.bookingNo-1].seatRow);
                                //System.out.println(MainFile.customerObjects[customerId].customertotalfare);
                                System.out.println("Booked Successfully...");
                            } else if(confirmation==2){
                                System.out.println("Not Confirmed : Re-Enter Your Details");
                            }

                        }

                    }
                }
            }
        }else
        {
            System.out.println("insufficient seats");
        }
    }
}
