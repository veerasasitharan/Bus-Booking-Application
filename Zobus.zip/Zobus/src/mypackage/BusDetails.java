package mypackage;

public class BusDetails
{
    String busType=null;
    int busId=0;
    int totalSeat=12;
    int bookedSeats=0;
    int availableSeat=12;
    int busFare=0;
    int totalBusFare=0;
    int cancellationNo=0;
    BusDetails(String busType,int busId,int busFare,int totalBusFare,int cancellationNo)
    {
        this.busType=busType;
        this.busId=busId;
        this.busFare=busFare;
        this.totalBusFare=totalBusFare;
        this.cancellationNo=0;
    }

}
