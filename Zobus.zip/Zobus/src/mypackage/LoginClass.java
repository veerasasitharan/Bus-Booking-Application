package mypackage;
import java.util.Scanner;
public class LoginClass
{
    static int customerId=0;
    public static void main(String[] args)
    {
       int i,numberoftickets=0,j;
        int availabelSeatNo = 0;
       boolean isValiduserName=false;
       String busType=null;
       Scanner scan=new Scanner(System.in);
       System.out.println("Enter Your userName");
       System.out.println("Enter Your userPasssword");
       String userName=scan.next();
        int userPassword=scan.nextInt();
        for(i=0;i<MainFile.customerNo;i++)
        {
            if((MainFile.customerObjects[i].customerName.equals(userName))&&(MainFile.customerObjects[i].customerPassword==userPassword))
            {
                isValiduserName=true;
                customerId=i;
                break;
            }
        }

       if(isValiduserName)
       {
           System.out.println("Login Successfully...");
           int choice=0;
           int[] busFilter=new int[4];
           String[] busFiltername=new String[4];
           String tem=null;
           do{
               System.out.println("1.Ticket Booking");
               System.out.println("2.Ticket Cancellation");
               System.out.println("3.Booked Details");
               System.out.println("4.Back");
               System.out.println("Enter Your Choice");
               choice=scan.nextInt();

               if(choice==1) {
                   if(MainFile.customerObjects[customerId].totalbookedtickets==0)
                   {
                       TicketBooking.toBookTicket();
                   }else
                   {
                       System.out.println("Booking Not Allowed : U have already Booked");
                   }

               } else if (choice==2) {
                   TicketCancelling.toCancelTicket();
               } else if (choice==3) {
                    showBookedDetails();

               } else if (choice>4) {
                   System.out.println("Invalid");
               }
           }while (choice!=4);
       }
       else
       {
           System.out.println("Invalid userName or userPassword");
       }

    }
    public static void showBookedDetails()
    {
        System.out.println("Your Booked Seats");
        for(int g=0;g<MainFile.customerNo;g++)
        {
            if(MainFile.customerObjects[g].customerId==customerId&&MainFile.customerObjects[g].totalbookedtickets>0)
            {
                System.out.println("bookingCustomerId        BookingseatNo       BookingseatRow ");
                for(int c=0;c<MainFile.bookingNo;c++)
                {
                    if((MainFile.bookingDetailsObjects[c].bookingCustomerId==g) && (MainFile.bookingDetailsObjects[c].bookingStatus.equals("Conformed")))
                    {
                        System.out.println(MainFile.bookingDetailsObjects[c].bookingCustomerId+"      "+MainFile.bookingDetailsObjects[c].seatNo+"        "+MainFile.bookingDetailsObjects[c].seatRow);
                    }
                }
                System.out.println("Total Amount    "+MainFile.customerObjects[g].customertotalfare);
            }
        }
    }
    static int busId=0;
   static boolean isSameCustomerId=false ,isSameGender=true,isSeatAvailabel=false;
    public static int isAvailabel(String busType,int seatNo,char seatRow,int customerId,String passengerGender)
    {

        isSameCustomerId=false;isSameGender=true;isSeatAvailabel=false;
       int availabelSeatNo=-1;
        for(int i=0;i<4;i++)
        {
            if(MainFile.busObjects[i].busType.equals(busType))
            {
                int temp=0,adjacentseatNo=0;
                int start=i*12;
                int end=start+12;
                busId=i;

                for(temp=start;temp<end;temp++)
                {

                    if(MainFile.busSeatObjects[temp].seatNo==seatNo&&MainFile.busSeatObjects[temp].seatRow==seatRow)
                    {
                        if(MainFile.busSeatObjects[temp].seatStatus.equals("Availabel"))
                        {
                           // availabelSeatNo=temp;
                                availabelSeatNo=temp;
                                isSeatAvailabel=true;

                                for(int x=0;x<MainFile.customerNo;x++)
                                {
                                    if(MainFile.customerObjects[x].totalbookedtickets>0)
                                    {
                                        for(int d=0;d<MainFile.bookingNo;d++)
                                        {
                                            if(MainFile.bookingDetailsObjects[d].busType.equals(busType)&&MainFile.bookingDetailsObjects[d].seatRow==seatRow)
                                            {
                                              //  System.out.println(MainFile.bookingDetailsObjects[d].seatNo);
                                               if(seatNo%2==1)
                                               {
                                                   if(seatNo+1==MainFile.bookingDetailsObjects[d].seatNo)
                                                   {
                                                       if(!MainFile.bookingDetailsObjects[d].passengerGender.equals(passengerGender))
                                                       {

                                                           isSameGender=false;
                                                       } if (MainFile.bookingDetailsObjects[d].bookingCustomerId==customerId) {

                                                       isSameCustomerId=true;
                                                   }
                                                       System.out.println(MainFile.bookingDetailsObjects[d].busType+" "+MainFile.bookingDetailsObjects[d].seatRow+" "+MainFile.bookingDetailsObjects[d].seatNo+"        "+MainFile.bookingDetailsObjects[d].passengerGender+"      "+passengerGender+"      "+MainFile.bookingDetailsObjects[d].bookingCustomerId+" "+customerId+" "+isSameCustomerId);
                                                   }


                                               }
                                               else
                                               {
                                                   if(seatNo-1==MainFile.bookingDetailsObjects[d].seatNo)
                                                   {
                                                       if(!MainFile.bookingDetailsObjects[d].passengerGender.equals(passengerGender))
                                                       {

                                                           isSameGender=false;
                                                       } if (MainFile.bookingDetailsObjects[d].bookingCustomerId==customerId) {

                                                           isSameCustomerId=true;
                                                       }
                                                       System.out.println(MainFile.bookingDetailsObjects[d].busType+" "+MainFile.bookingDetailsObjects[d].seatRow+" "+MainFile.bookingDetailsObjects[d].seatNo+"        "+MainFile.bookingDetailsObjects[d].passengerGender+"      "+passengerGender+"      "+MainFile.bookingDetailsObjects[d].bookingCustomerId+" "+customerId+" "+isSameCustomerId);
                                                   }


                                               }

                                            }


                                        }
                                    }
                                }


                        }else
                        {
                            System.out.println("Seat Not Availabale");
                        }

                    }
                }
                break;
            }
        }

        if(!isSameGender)
        {
            if(!isSameCustomerId)
            {
                System.out.println("Seat Available But adjacent seat occupied by other gender : Re-Enter Your Details");
                availabelSeatNo=-1;
            }
        }
        return availabelSeatNo;
    }

}
