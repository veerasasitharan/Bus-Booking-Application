package mypackage;

public class CustomerDetails
{
     int customerAge=0,customerPassword=0,customerId=0,totalbookedtickets=0,customertotalfare=0;
     String customerName=null,customerGender=null;
    CustomerDetails(int customerId,String customerName,int customerPassword,int customerAge,String customerGender,int customertotalfare)
    {
        this.customerId=customerId;
        this.customerName=customerName;
        this.customerPassword=customerPassword;
        this.customerAge=customerAge;
        this.customerGender=customerGender;
        this.customertotalfare=customertotalfare;
    }

}
