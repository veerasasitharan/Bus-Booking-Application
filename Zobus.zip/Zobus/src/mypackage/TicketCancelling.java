package mypackage;

import java.util.Scanner;

public class TicketCancelling
{
    public static void toCancelTicket()
    {
        Scanner scan=new Scanner(System.in);
        System.out.println("Your Booked Seats");
       LoginClass.showBookedDetails();
        System.out.println("1.All Seats Cancel");
        System.out.println("2.Selected Seats Cancel");
        int isAllCancel=scan.nextInt();
        int temp=0,z;
        int cancelBusId=0;
        if(isAllCancel==1)
        {
            for(int g=0;g<MainFile.customerNo;g++)
            {
                if(MainFile.customerObjects[g].customerId==LoginClass.customerId&&MainFile.customerObjects[g].totalbookedtickets>0)
                {
                    //  System.out.println("BookingId        BookingseatNo       BookingseatRow "+MainFile.bookingNo);
                    for(int c=0;c<MainFile.bookingNo;c++)
                    {
                        if(MainFile.bookingDetailsObjects[c].bookingCustomerId==g && MainFile.bookingDetailsObjects[c].bookingStatus.equals("Conformed"))
                        {
                            for(int h=0;h<4;h++)
                            {
                                if(MainFile.bookingDetailsObjects[c].busType.equals(MainFile.busObjects[h].busType))
                                {
                                    cancelBusId=MainFile.busObjects[h].busId;
                                    System.out.println(cancelBusId);
                                }
                            }
                            MainFile.bookingDetailsObjects[c].bookingStatus="Cancelled";
                            MainFile.busSeatObjects[MainFile.bookingDetailsObjects[c].seatId].seatStatus = "Availabel";
                            MainFile.customerObjects[LoginClass.customerId].totalbookedtickets -= 1;
                            temp=(MainFile.busObjects[cancelBusId].busFare*50)/100;
                            MainFile.customerObjects[LoginClass.customerId].customertotalfare= MainFile.customerObjects[LoginClass.customerId].customertotalfare-temp;
                            MainFile.busObjects[cancelBusId].totalBusFare-=temp;
                            MainFile.busObjects[cancelBusId].bookedSeats -= 1;
                            MainFile.busObjects[cancelBusId].availableSeat += 1;
                            MainFile.busObjects[cancelBusId].cancellationNo+=1;
                            MainFile.Totalcancellationfee+=temp;
                            System.out.println("Total Amount     "+MainFile.customerObjects[LoginClass.customerId].customertotalfare+"      fine Amount   "+temp);
                        }
                    }
                }
            }
          //  System.out.println("Total Amount     "+MainFile.customerObjects[LoginClass.customerId].customertotalfare+"      fine Amount   "+temp);
            System.out.println("Cancelled Successfully...");
        }
        else if(isAllCancel==2)
        {
            System.out.println("Enter No of Ticket to Cancel");
            int numberofticketcancel=scan.nextInt();

            for(int g=0;g<MainFile.customerNo;g++)
            {
                if(MainFile.customerObjects[g].customerId==LoginClass.customerId&&MainFile.customerObjects[g].totalbookedtickets>0)
                {
                    //  System.out.println("BookingId        BookingseatNo       BookingseatRow ");
                    for(int v=0;v<numberofticketcancel;v++)
                    {
                        System.out.println("Enter BusType");
                        System.out.println("Enter seatRow");
                        System.out.println("Enter seatNo");
                        String busTypeToCancel=scan.next();
                        char seatRowToCanel=scan.next().charAt(0);
                        int seatNoToCancel=scan.nextInt();
                        for(int c=0;c<MainFile.bookingNo;c++)
                        {
                            if(MainFile.bookingDetailsObjects[c].bookingCustomerId==g && MainFile.bookingDetailsObjects[c].bookingStatus.equals("Conformed"))
                            {
                                // System.out.println(MainFile.bookingDetailsObjects[c].bookingId);
                                for(z=0;z<4;z++)
                                {
                                    //System.out.println(MainFile.busObjects[z].busType.equals(MainFile.bookingDetailsObjects[c].busType));
                                    if(MainFile.busObjects[z].busType.equals(busTypeToCancel))
                                    {
                                        /// System.out.println(z+"       "+cancelBusId);
                                        break;

                                    }
                                }
                                if(MainFile.bookingDetailsObjects[c].busType.equals(busTypeToCancel)&&MainFile.bookingDetailsObjects[c].seatNo==seatNoToCancel&&MainFile.bookingDetailsObjects[c].seatRow==seatRowToCanel)
                                {
                                    cancelBusId=MainFile.busObjects[z].busId;
                                    //   System.out.println(customerId+"       "+cancelBusId+"       "+c+" "+MainFile.bookingDetailsObjects[c].busType);
                                    MainFile.bookingDetailsObjects[c].bookingStatus="Cancelled";
                                    MainFile.busSeatObjects[MainFile.bookingDetailsObjects[c].seatId].seatStatus = "Availabel";
                                    MainFile.customerObjects[LoginClass.customerId].totalbookedtickets -= 1;
                                    temp=(MainFile.busObjects[cancelBusId].busFare*50)/100;
                                    MainFile.customerObjects[LoginClass.customerId].customertotalfare= MainFile.customerObjects[LoginClass.customerId].customertotalfare-temp;
                                    MainFile.busObjects[cancelBusId].totalBusFare-=temp;
                                    MainFile.busObjects[cancelBusId].bookedSeats -= 1;
                                    MainFile.busObjects[cancelBusId].availableSeat += 1;
                                    MainFile.Totalcancellationfee+=temp;
                                    System.out.println("Total Amount     "+MainFile.customerObjects[LoginClass.customerId].customertotalfare+"  fine Amount   "+temp);
                                }

//

                            }

                        }
                     //   System.out.println("Total Amount     "+MainFile.customerObjects[LoginClass.customerId].customertotalfare+"  fine Amount   "+temp);
                        System.out.println("Cancelled Successfully...");
                    }

                }
            }

        }
    }

}
