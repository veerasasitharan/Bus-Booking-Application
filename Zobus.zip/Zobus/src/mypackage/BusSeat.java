package mypackage;

public class BusSeat
{
    int seatNo=0;
    int busId=0;
  String seatStatus=null;
    char seatRow;
    int seatId=0;
    BusSeat(int busId,int seatNo,char seatRow,String seatStatus,int seatId)
    {
        this.busId=busId;
        this.seatNo=seatNo;
        this.seatRow=seatRow;
        this.seatStatus=seatStatus;
        this.seatId=seatId;
    }
}
